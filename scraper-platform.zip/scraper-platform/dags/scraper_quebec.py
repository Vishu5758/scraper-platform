# DAG stub for Quebec
