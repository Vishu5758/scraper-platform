# file: src/processors/parse/__init__.py
"""
Parsing helpers: HTML → structured dicts, schema drift checks, cleanup.
"""
