# file: src/processors/exporters/__init__.py
"""
Exporters for pushing processed records into external sinks (DB, CSV, JSON, etc.).
"""
