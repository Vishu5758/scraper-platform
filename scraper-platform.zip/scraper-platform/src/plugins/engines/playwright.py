"""Plugin adapter for Playwright helpers."""

from src.engines.playwright_engine import goto_with_retry

__all__ = ["goto_with_retry"]
