"""Plugin adapter for Selenium browser sessions."""

from src.engines.selenium_engine import open_with_session

__all__ = ["open_with_session"]
