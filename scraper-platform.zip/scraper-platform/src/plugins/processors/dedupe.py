"""Plugin adapter for record de-duplication helper."""

from src.processors.dedupe import dedupe_records

__all__ = ["dedupe_records"]
