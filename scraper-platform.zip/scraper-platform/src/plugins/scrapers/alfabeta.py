"""Plugin facade for the AlfaBeta scraper pipeline."""

from src.scrapers.alfabeta.pipeline import run_alfabeta

__all__ = ["run_alfabeta"]
