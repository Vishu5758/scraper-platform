"""Plugin facade for the template/sample source pipeline."""

from src.scrapers.template.pipeline import run_template

__all__ = ["run_template"]
