# contracts stub
