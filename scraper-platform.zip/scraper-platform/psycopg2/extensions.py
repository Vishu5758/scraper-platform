from psycopg2 import DummyConnection as connection  # type: ignore
