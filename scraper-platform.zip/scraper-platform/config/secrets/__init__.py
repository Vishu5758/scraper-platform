# file: config/secrets/__init__.py
"""
Namespace for Vault-related config and secret templates.
"""
