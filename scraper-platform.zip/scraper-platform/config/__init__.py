# file: config/__init__.py
"""
Namespace package for static configuration files.
This exists mainly so tools can safely import `config` if needed.
"""
