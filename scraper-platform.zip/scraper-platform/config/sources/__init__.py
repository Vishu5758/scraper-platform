# file: config/sources/__init__.py
"""
Helper namespace for per-source YAML configs.
"""
